//
//  SwiftyPoke.h
//  SwiftyPoke
//
//  Created by Kalvin Loc on 1/20/16.
//  Copyright © 2016 Red Panda. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftyPoke.
FOUNDATION_EXPORT double SwiftyPokeVersionNumber;

//! Project version string for SwiftyPoke.
FOUNDATION_EXPORT const unsigned char SwiftyPokeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftyPoke/PublicHeader.h>


